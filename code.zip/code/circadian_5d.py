# -*- coding: utf-8 -*-
"""
Created on Sat Nov 11 09:34:18 2023

@author: 12147
"""

# -*- coding: utf-8 -*-




import torch
import torchsde
import pandas as pd
import random
import time
import csv
from tqdm import tqdm
from math import sqrt


device = torch.device("cpu" if torch.cuda.is_available() else "cpu")

batch_size, state_size, brownian_size = 200, 5, 5
H = 150
t_size = 101
print(device)
class TwoLayerNet(torch.nn.Module):
    def __init__(self, D_in, H, D_out):
        """
        In the constructor we instantiate two nn.Linear modules and assign them as
        member variables.
        """
        super(TwoLayerNet, self).__init__()
        self.linear1 = torch.nn.Linear(D_in, H)
        self.linear2 = torch.nn.Linear(H, H)
        self.linear3 = torch.nn.Linear(H, D_out)
        
        #return data
    
    def forward(self, x):
        """
        In the forward function we accept a Tensor of input data and we must return
        a Tensor of output data. We can use Modules defined in the constructor as
        well as arbitrary operators on Tensors.
        """
        h_relu1 = self.linear1(x)
        h_relu1 = torch.relu(h_relu1)
        h_relu2 = self.linear2(h_relu1)
        h_relu2 = torch.relu(h_relu2)
        y_pred = self.linear3(h_relu2)
        return y_pred
    
class SDE(torch.nn.Module):
    noise_type = 'general'
    sde_type = 'ito'

    def __init__(self):
        super().__init__()
        self.mu = TwoLayerNet(state_size, H,#torch.nn.Linear(state_size, 
                                  state_size)
        self.sigma = TwoLayerNet(state_size, H,#torch.nn.Linear(state_size, 
                                  state_size * brownian_size)#torch.nn.Linear(state_size, 
                                     #state_size * brownian_size)

    # Drift
    def f(self, t, y):
        t = t.expand(y.size(0), 1)
        ty = torch.cat([t, y], dim=1).to(device)
        #f_truth = torch.zeros(y.shape[0], y.shape[1]).to(device)
        #for i in range(y.shape[0]):
        #    f_truth[i, 0] = - y[i, 1]
        #    f_truth[i, 1] = y[i, 0]
            
        return self.mu(y) #+ f_truth # shape (batch_size, state_size)

    # Diffusion
    def g(self, t, y):
        t = t.expand(y.size(0), 1)
        ty = torch.cat([t, y], dim=1).to(device)
        noise = torch.zeros(batch_size, state_size, brownian_size)
        total = self.sigma(y).view(batch_size, 
                                  state_size, 
                                  brownian_size)
        for j in range(5):
            noise[:, j, j] = total[:, j, j]
            
        return noise
    
a = 0.1
b = 5
sigma = 0.4#0.5
v = 0.1
from math import sqrt
print('start')
mu1 = 0.1
mu2 = 0.2
Sigma = [0.1, 0.05, 0.1, 0, 0.02]

params = [0 for i in range(19)]
params[1] = 1 # KI microM
params[2] = 0.2 # Kd microM
params[3] = 0.5 # Km microM
params[4] = 2 # K1 microM
params[5] = 2 # K2 microM
params[6] = 2 # K3 microM
params[7] = 2 # K4 microM
params[8] = 1.9 # k1 /h
params[9] = 1.3 # k2 /h
params[10] = 0.38 # ks /h
params[11] = 0.95 # vd microM/h
params[12] = 0.76 # vs microM/h
params[13] = 0.65 # vm microM/h
params[14] = 3.2 # V1 microM/h
params[15] = 1.58 # V2 microM/h
params[16] = 5 # V3 microM/h
params[17] = 2.5 # V4 microM/h
params[18] = 4 # n

class SDE_truth(torch.nn.Module):
    noise_type = 'general'
    sde_type = 'ito'
    
    def __init__(self):
        super().__init__()


    # Drift
    def f(self, t, y):
        du = torch.zeros(y.shape[0], y.shape[1]).to(device)
        for i in range(y.shape[0]):
            du[i, 0] = params[12]*(params[1]**params[18])/((params[1]**params[18])+(y[i, 4]**params[18])) - params[13]*y[i,0]/(y[i,0]+params[3]) # M, mRNA of paramsER
            du[i, 1] = params[10]*y[i,0] - params[14]*y[i,1]/(y[i,1]+params[4]) + params[15]*y[i,2]/(y[i,2]+params[5]) # unparamshosparamshorylated paramsER
            du[i, 2] = params[14]*y[i,1]/(y[i,1]+params[4]) - params[15]*y[i,2]/(y[i,2]+params[5]) - params[16]*y[i,2]/(y[i,2]+params[6]) + params[17]*y[i,3]/(y[i,3]+params[7]) # mono-params paramsER
            du[i, 3] = params[16]*y[i,2]/(y[i,2]+params[6]) - params[17]*y[i,3]/(y[i,3]+params[7]) - params[8]*y[i,3] + params[9]*y[i,4] - params[11]*y[i,3]/(y[i,3]+params[2]) # bi-params paramsER
            du[i, 4] = params[8]*y[i,3] - params[9]*y[i,4] # nuclear PER
            
        return du  # shape (batch_size, state_size)

    # Diffusion
    def g(self, t, y):
        g_truth = torch.zeros(y.shape[0], y.shape[1], brownian_size).to(device)
        for i in range(y.shape[0]):
            g_truth[i, 0, 0] = Sigma[0] * y[i, 0] #* sqrt(t+1)
            g_truth[i, 1, 1] = Sigma[1] * y[i, 1]
            g_truth[i, 2, 2] = Sigma[2]  #* sqrt(t+1)
            g_truth[i, 3, 3] = Sigma[3] * y[i, 3]
            g_truth[i, 4, 4] = Sigma[4] 
            
        return g_truth

sde = SDE().to(device)
#sde.load_state_dict(torch.load('circadian_5dnew.pkl'))
sde_truth = SDE_truth().to(device)
y0 = torch.zeros(batch_size, state_size).to(device)
for i in range(batch_size):
    if i < 100:
        y0[i, 0] = 1#1#0.5 #+ float(torch.randn(1)[0] * 0.5) #csv_data[i][0]
        y0[i, 1] = 0.5#0.5
        y0[i, 2] = 1#2#0.5#2#0.5 #+ float(torch.randn(1)[0] * 0.5) #csv_data[i][0]
        y0[i, 3] = 1#0.5#1#0
        y0[i, 4] = 1.5#1
    else:
        y0[i, 0] = 1#1#0.5 #+ float(torch.randn(1)[0] * 0.5) #csv_data[i][0]
        y0[i, 1] = 0.5
        y0[i, 2] = 1#2#2#0.5 #+ float(torch.randn(1)[0] * 0.5) #csv_data[i][0]
        y0[i, 3] = 1#0.5#1#0
        y0[i, 4] = 1.5#1
        
    if y0[i, 0] <= 0:
        print("error")
        
t_end = 25#10
ts = torch.linspace(0, t_end, t_size).to(device)

ys_truth = torchsde.sdeint(sde_truth, y0, ts).to(device)
print('start')
truth_data = pd.DataFrame(data = [[float(ys_truth[i, j, 0]) for i in range(t_size)] for j in range(batch_size)])
truth_data.to_csv('ground_truth_ciacadian1new7.csv', header=False, index = False)

truth_data = pd.DataFrame(data = [[float(ys_truth[i, j, 1]) for i in range(t_size)] for j in range(batch_size)])
truth_data.to_csv('ground_truth_ciacadian2new7.csv', header=False, index = False)

truth_data = pd.DataFrame(data = [[float(ys_truth[i, j, 2]) for i in range(t_size)] for j in range(batch_size)])
truth_data.to_csv('ground_truth_ciacadian3new7.csv', header=False, index = False)

truth_data = pd.DataFrame(data = [[float(ys_truth[i, j, 3]) for i in range(t_size)] for j in range(batch_size)])
truth_data.to_csv('ground_truth_ciacadian4new7.csv', header=False, index = False)

truth_data = pd.DataFrame(data = [[float(ys_truth[i, j, 4]) for i in range(t_size)] for j in range(batch_size)])
truth_data.to_csv('ground_truth_ciacadian5new7.csv', header=False, index = False)

criterion = torch.nn.MSELoss(reduction='sum')
optimizer = torch.optim.Adam(sde.parameters(), lr=0.002,betas= (0.9, 0.999), weight_decay=0.005)
epoch = 700
loss_list = []
ttime = time.time()
g_error_list = []
sigma_error_list = []


        
from math import pi    

       
import ot     
def distance(P, Q):
    cost_matrix = ot.dist(P, Q,metric='sqeuclidean')
    return cost_matrix

def w2_decoupled(y, y_pred):
    batch_size = y.shape[1]
    state_size = y.shape[2]
    t_size = y.shape[0]
    loss = 0
    for i in range(1, t_size):
        weights = torch.tensor([1/batch_size for _ in range(batch_size)]).to(device)

        loss += ot.emd2(weights, weights, distance(y[i, :, :], y_pred[i, :, :]))
    
    return loss

import pdb
error_f = []
error_s = []
loss_list = []

def total_error1(sde_truth, sde, i0):
    
    summ = 0
    summ_ref = 0
    
    for i in range(t_size):
        summ += torch.sum(torch.abs( sde.f(ts[i], ys_truth[i]) - sde_truth.f(ts[i], ys_truth[i])))
        summ_ref += torch.sum(torch.abs(sde_truth.f(ts[i], ys_truth[i])))
                
    summ1 = 0
    summ1_ref = 0
    for i in range(t_size):
        s1 = sde_truth.g(ts[i], ys_truth[i])
        s2 = sde.g(ts[i], ys_truth[i])
        #if i0 > 50:
        #    print(s1, s2)
            #pdb.set_trace()
            
        for j in range(ys.shape[1]):
            summ1_ref += torch.sum(torch.abs(s1[j]))
            summ1 += torch.sum(torch.abs(torch.abs(s2[j, 0, 0]) - torch.abs(s1[j, 0, 0])))
            summ1 += torch.sum(torch.abs(torch.abs(s2[j, 1, 1]) - torch.abs(s1[j, 1, 1])))
            summ1 += torch.sum(torch.abs(torch.abs(s2[j, 2, 2]) - torch.abs(s1[j, 2, 2])))
            summ1 += torch.sum(torch.abs(torch.abs(s2[j, 3, 3]) - torch.abs(s1[j, 3, 3])))
            summ1 += torch.sum(torch.abs(torch.abs(s2[j, 4, 4]) - torch.abs(s1[j, 4, 4])))
        
    print(summ / summ_ref, summ1 / summ1_ref)
    return float(summ / summ_ref), float(summ1 / summ1_ref)


for i0 in tqdm(range(epoch)):
    #print(i)
    ys = torchsde.sdeint(sde, y0, ts).to(device)  
    loss =  w2_decoupled(ys, ys_truth)

    if i0 % 10 == 0:
        print(i0, loss.item(), time.time() - ttime)
        f_error, s_error = total_error1(sde_truth, sde, i0)
        error_f.append(f_error)
        error_s.append(s_error)
        ttime = time.time()
        
    loss_list.append(loss.item())
    optimizer.zero_grad()
    loss.backward()
    optimizer.step()




predict_data = pd.DataFrame(data = [[float(ys[i, j, 0]) for i in range(t_size)] for j in range(batch_size)])
predict_data.to_csv('predict_circadian1new7.csv', header=False, index = False)

predict_data = pd.DataFrame(data = [[float(ys[i, j, 1]) for i in range(t_size)] for j in range(batch_size)])
predict_data.to_csv('predict_circadian2new7.csv', header=False, index = False)

predict_data = pd.DataFrame(data = [[float(ys[i, j, 2]) for i in range(t_size)] for j in range(batch_size)])
predict_data.to_csv('predict_circadian3new7.csv', header=False, index = False)

predict_data = pd.DataFrame(data = [[float(ys[i, j, 3]) for i in range(t_size)] for j in range(batch_size)])
predict_data.to_csv('predict_circadian4new7.csv', header=False, index = False)

predict_data = pd.DataFrame(data = [[float(ys[i, j, 4]) for i in range(t_size)] for j in range(batch_size)])
predict_data.to_csv('predict_circadian5new7.csv', header=False, index = False)

loss_data = pd.DataFrame(data = error_f)
loss_data.to_csv('f_error_circadian5d_given7.csv', header=False, index = False)

loss_data = pd.DataFrame(data = error_s)
loss_data.to_csv('s_error_circadian5d_given7.csv', header=False, index = False)

loss_data = pd.DataFrame(data = loss_list)
loss_data.to_csv('loss2d_circadian6.csv', header=False, index = False)
torch.save(sde.state_dict(), 'circadian_5dnew7'+'.pkl')

