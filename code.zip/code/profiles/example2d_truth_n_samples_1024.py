import torch

mu1 = 0.1
mu2 = 0.2
Sigma = [[0.2, -0.1], [-0.1, 0.1]]
n_samples = 1024
t_size = 101

ts = torch.linspace(0, 5, t_size)

torch.manual_seed(0)
u0 = torch.ones(n_samples, 2) * torch.tensor([1, 0.5])

truth_label = 'truth_n_samples_1024'
u_truth_savepath = 'data/example2d_truth_n_samples_1024.pt'
 
