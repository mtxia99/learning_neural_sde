batch_size, state_size, brownian_size = 64, 1, 1
hidden_size = 32
mlp_size = 32
mlp_layers = 2
η = 2e-3
β = (0.9, 0.999)
weight_decay = 0.005
n_epoch_per_epoch = 1
nsde_label = 'wgan_ncde_n_samples_64'
swa_start = 1000

