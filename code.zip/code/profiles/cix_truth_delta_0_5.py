import torch
a, b, σ = 1, 5, 0.5
n_samples = 200
t_size = 41
δ = 0.5
ts = torch.linspace(0, 2, t_size)

torch.manual_seed(0)
# initial condition
u0 = torch.ones(n_samples, 1) * 2
noise = torch.randn(u0.size()) * torch.sqrt(torch.tensor(δ))
u0 += noise
u0[u0 < 0] = 1e-3

truth_label = 'truth_delta_0.5'
u_truth_savepath = 'data/cix_truth_delta_0.5.pt'

