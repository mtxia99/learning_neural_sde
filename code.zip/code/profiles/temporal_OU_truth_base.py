import torch

μ, θ, σ = 0.02, 0.1, 0.4
n_samples = 256
t_size = 64

ts = torch.linspace(0, 63, t_size)

torch.manual_seed(0)
u0 = torch.zeros(n_samples, 1)

truth_label = 'truth_base'
u_truth_savepath = 'data/temporal_OU_truth_base.pt'