import torch

a, b, σ = 1, 5, 0.5
N_samples = [50,100,200,400]
t_size = 41

ts = torch.linspace(0, 2, t_size)

torch.manual_seed(1234)

u0s = [torch.randn(n_samples, 1) * 0.5 + 2 
        for n_samples in N_samples]
